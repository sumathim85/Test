package org.prodapt.raf;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntakeportalApplicationTests {

//	@Test
//	//void contextLoads() {
//	}

}
