from jinja2 import Template
import re
import json
import os
import requests
from robot.api.deco import keyword
from robot.output.logger import LOGGER

class GponUtil:
    def __init__(self):
        # proppath = (os.path.dirname(os.path.realpath(__file__)))
        file = open('conf/GPON_Basic_Config.json', 'r')
        self._config = json.load(file)
    @keyword('Validate Json Input')
    def validate_user_input(self,json_input):
        ipv6re = "(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:" \
                 "|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4})" \
                 "{1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}" \
                 "|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})" \
                 "|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]" \
                 "|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]" \
                 "|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))[\/]127"
        if re.fullmatch("[a-zA-Z0-9.]+", json_input["XGW Info"][0]["Node Name"]) is None or \
                re.fullmatch("[A-Z]+", (json_input["OLT Info"][0]["Node Name"]).upper()) is None or \
                re.fullmatch("((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[/]31+",json_input["OLT Info"][0]["IPv4 P-P address /31"]) is None or \
                re.fullmatch(ipv6re, json_input["OLT Info"][0]["IPv6 P-P address /127"]) is None or \
                re.fullmatch("\d+[/]\d+[/]\d+", json_input["XGW Info"][0]["Link #1"]["Port ID"]) is None or \
                re.fullmatch("[a-zA-Z0-9,\s]+", json_input["OLT Info"][0]["Node Address"]) is None or \
                re.fullmatch("[A-Z\s]+[-]\d+", (json_input["OLT Info"][0]["Node Model"]).upper()) is None:
            desc = "Please enter valid XGW Node Name" if re.fullmatch("[a-zA-Z0-9.]+", json_input["XGW Info"][0]["Node Name"]) is None else \
                "Please enter valid OLT Node Name" if re.fullmatch("[A-Z]+", (json_input["OLT Info"][0]["Node Name"]).upper()) is None else \
                    "Please enter valid OLT IPv4" if re.fullmatch(
                        "((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)[/]31+",
                        json_input["OLT Info"][0]["IPv4 P-P address /31"]) is None \
                        else "Please enter valid OLT IPv6" if re.fullmatch(ipv6re, json_input["OLT Info"][0][
                        "IPv6 P-P address /127"]) is None \
                        else "Please enter valid XGW Link#1 Port ID" if re.fullmatch("\d+[/]\d+[/]\d+",
                                                                                     json_input["XGW Info"][0][
                                                                                         "Link #1"]["Port ID"]) is None \
                        else "Please enter valid OLT Node Address" if re.fullmatch("[a-zA-Z0-9,\s]+",
                                                                                   json_input["OLT Info"][0][
                                                                                       "Node Address"]) is None \
                        else "Please enter valid Node Model" if re.fullmatch("[A-Z\s]+[-]\d+", (
                    json_input["OLT Info"][0]["Node Model"]).upper()) is None else "Validation Success"
            return desc, "Failure"
        return "Success", "Success"


    @keyword('Generate Config')
    def Generate_Config(self,user_input,file):
        try:
            f = open(file, "r")
            string = f.read()
            tm = Template(string)
            msg = tm.render(input=user_input)
            if len(msg) == 0:
                return "Invalid Config", "Failure"
            return msg, "success"
        except Exception as e:
            print("Config Generation Error" + str(e))
            return "Error", "Failure"


    @keyword('Mail')
    def mail(self,mail_config,id,mail_id,access_token):
        try:
            f = open(self._config["mailFile"], "r")
            string = f.read()
            tm = Template(string)
            msg = tm.render(config=mail_config,orderId=id)
            if len(msg) == 0:
                return "Invalid Config","Failure"
            url = self._config['middleWareUrl'] + self._config['mail']['uri']
            headers = self._config['mail']['headers']
            headers["Authorization"]='Bearer '+access_token
            body = self._config['mail']['body']
            body['testingRecipients']['to'] = mail_id
            body['subject'] = "TAF – Order ID : " + str(id) + " – Prepared config commands"
            body['mailContent'] = msg
            print(msg)
            response = requests.request("POST", url, headers=headers, data=json.dumps(body), verify=False)
            print(response.text)
            print(response.status_code)
            return "success" if response.status_code==200 else "failure"
        except Exception as e:
            print("Config Generation Error"+str(e))
            return "Failure"




