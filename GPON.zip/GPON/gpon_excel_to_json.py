import pandas as pd
import json


from robot.api.deco import keyword
from robot.output.logger import LOGGER

@keyword('OLT To Json')
def Olt_Info_Excel_to_json(Input_file,basic_conf):
    """------------------------------OLT Info-------------------------------------"""
    try:

        data = pd.read_excel(Input_file, sheet_name='Sheet1')
        print("Execution starts ----------------------OLT Info----------------------------!")
        df_olt = data.filter(items=['OLT Info']).dropna()
        df5 = data.filter(items=['Unnamed: 5'])
        df6 = data.filter(items=['Unnamed: 6']).dropna()
        olt_info = df_olt['OLT Info'].tolist()
        un_name_col5 = df5['Unnamed: 5'].tolist()
        un_name_col6 = df6['Unnamed: 6'].tolist()
        links = [un_name_col6[i] for i in range(len(un_name_col5)) if type(un_name_col5[i]) == str]
        links_count = len(links)
        df5 = df5.dropna()
        un_name_col5 = df5['Unnamed: 5'].tolist()
        test_values = [j for j in un_name_col6 if j not in links]
        child_value = [j for j in un_name_col6 if j not in test_values]
        j = 0
        res = {}
        data_list = []
        count = 0
        for key in olt_info:
            if 'Link #' in key:
                count += 1
        childs = links_count // count
        for key in olt_info:
            for value in test_values:
                if 'Link #' in key:
                    child_values = [child_value[j+i] for i in range(childs)]
                    obj = dict(zip(un_name_col5, (child_values)))
                    j = j + childs
                    res[key] = obj
                    link=key.split("#")
                    # if(int(link[1])>1):
                    #     link_config_update(key, res[key],basic_conf)
                else:
                    res[key] = value
                    test_values.remove(value)
                break
        data_list.append(res)
        data_dict = {df_olt.columns[0]: data_list}
        print("successfully completed-----------------OLT Info--------------!")
        return data_dict
    except Exception as e:
        print("something wrong", e)
@keyword('Basic Setup')
def basic_setup(basic_conf):
    with open(basic_conf['configFiles']['linkConfig'], 'w') as f:
        f.close()
    with open(basic_conf['cardTypeConf'], 'w') as f:
        f.close()
@keyword('Link Config Update')
def link_config_update(value,basic_conf):
    with open(basic_conf['configFiles']['linkConfig'], 'a+') as f:
        command = basic_conf['linkConfigCommand'].replace("LINKPORT", str(value["Port ID"]))
        f.write(command)
        f.close()

@keyword('Card Type Config')
def Card_Type_Config(line,link_config_comand):
    data=line.split()
    slot= data[0].split('/')
    command = link_config_comand['ponPortsConfigCommand'].replace("LTSLOT", slot[1])
    port = command.replace("PONPORT", slot[2])
    if data[1]=='5.5.5.5':
        command = link_config_comand['cartConfigCommandFWLT-b'].replace("CARDSLOT", data[0])
        with open(link_config_comand['cardTypeConf'],"a+") as f :
            f.write(command)
            f.write(port)
            f.close()
    elif data[1]=='21.1.1.1':
        with open(link_config_comand['cardTypeConf'],"a+") as f :
            command = link_config_comand['cartConfigCommandFWLT-c'].replace("CARDSLOT", data[0])
            f.write(command)
            f.write(port)
            f.close()

@keyword('XGW To Json')
def Xgw_Info_Excel_to_json(Input_file):
    try:
        data = pd.read_excel(Input_file, sheet_name='Sheet1')
        print("Execution starts-------------------------XGW Info----------------------------------!")
        df_xgw = data.filter(items=['XGW Info']).dropna()  # parentkeys
        df1 = data.filter(items=['Unnamed: 1'])  # link and cpe ip keys
        df2 = data.filter(items=['Unnamed: 2'])  # server keys
        df3 = data.filter(items=['Unnamed: 3'])  # values
        xgw_info = df_xgw['XGW Info'].tolist()
        un_name_col1 = df1['Unnamed: 1'].tolist()
        un_name_col2 = df2['Unnamed: 2'].tolist()
        un_name_col3 = df3['Unnamed: 3'].tolist()
        linkcpe = [un_name_col3[i] for i in range(len(un_name_col1)) if type(un_name_col1[i]) == str]
        link = linkcpe[:-4]
        cpe = linkcpe[-4:]
        server = [un_name_col3[i] for i in range(len(un_name_col2)) if type(un_name_col2[i]) == str]
        df1 = data.filter(items=['Unnamed: 1']).dropna()  # link and cpe ip keys
        df2 = data.filter(items=['Unnamed: 2']).dropna()  # server keys
        df3 = data.filter(items=['Unnamed: 3']).dropna()  # values
        un_name_col1 = df1['Unnamed: 1'].tolist()
        un_name_col2 = df2['Unnamed: 2'].tolist()
        un_name_col3 = df3['Unnamed: 3'].tolist()
        link_key = un_name_col1[:-4]
        cpe_key = un_name_col1[-4:]
        test_values = [j for j in un_name_col3 if j not in linkcpe and j not in server]
        j = k = s = count = count1 = count2 = 0
        res = {}
        data_list = []
        for key in xgw_info:
            if 'Link #' in key:
                count += 1
            if 'CPE' in key:
                count1 += 1
            if 'Server' in key:
                count2 += 1
        childs = len(link) // count
        childs1 = len(cpe) // count1
        childs2 = len(server) // count2
        for key in xgw_info:
            if 'Link #' in key:
                child_values = [link[j + i] for i in range(childs)]
                obj = dict(zip(link_key, child_values))
                j = j + childs
                res[key] = obj
            elif 'CPE' in key:
                child_value1 = [cpe[i + k] for i in range(childs1)]
                obj = dict(zip(cpe_key, child_value1))
                k = k + childs1
                res[key] = obj
            elif 'Server' in key:
                child_value2 = [server[i + s] for i in range(childs2)]
                obj = dict(zip(un_name_col2, child_value2))
                s = s + childs2
                res[key] = obj
            else:
                for value in test_values:
                    res[key] = value
                    test_values.remove(value)
                    break
        data_list.append(res)
        data_dict = {df_xgw.columns[0]: data_list}
        print("successfully completed ---------------XGW Info--------------!")
        return data_dict
    except Exception as e:
        print("something wrong", e)

@keyword('Merging OLT & XGw')
def Merging_to_info(Xgw_info_output,OLT_info_output,configFilePath):
    try:
        main_data_dict = {}
        main_data_dict.update(Xgw_info_output)
        main_data_dict.update(OLT_info_output)
        """---------------converting dictionary to json---------------------"""
        with open(configFilePath, "w") as writefile:
            json.dump(main_data_dict, writefile, indent=2)

        print("successfully JSON File generated")
    except Exception as e:
        print("something wrong", e)
"""Function call"""

# Input_file = 'Turnup-Sheet-TRNUONEDOLT_10x.xlsx'
# Xgw_info_output = Xgw_Info_Excel_to_json(Input_file)
# OLT_info_output = Olt_Info_Excel_to_json(Input_file)
# Excel_to_json_out = Merging_to_info(Xgw_info_output,OLT_info_output)

